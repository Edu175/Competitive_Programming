#include <string>
#include <vector>

using namespace std;

long long zetadieta(int C, int P, int G) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
