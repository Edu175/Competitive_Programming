#include <string>
#include <vector>

using namespace std;

long long desalambrando(int N, vector<int> &a, vector<int> &b, vector<int> &costo) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
