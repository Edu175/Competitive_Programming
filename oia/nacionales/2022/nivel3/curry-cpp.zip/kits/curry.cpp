#include <string>
#include <vector>

using namespace std;

long long curry(vector<string> &palabras, vector<int> &significados) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
