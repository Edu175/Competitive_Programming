#include <string>
#include <vector>

using namespace std;

void inicializar() {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

void nuevoNumero(int x) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}

int contar(int a, int b) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
