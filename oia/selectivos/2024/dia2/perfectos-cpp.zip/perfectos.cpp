#include <string>
#include <vector>

using namespace std;

long long perfectos(vector<int> &ronda) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
