#pragma once

int getDistance(int i, int j);
