#include <string>
#include <vector>

using namespace std;

int panes(vector<int> &ciudades, vector<int> &peajes) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
