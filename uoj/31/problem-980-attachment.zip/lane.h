#ifndef LANE_H
#define LANE_H

int solve(int subtask);

void clockwise();
void anticlockwise();

void flip();
bool ask();

#endif // LANE_H
