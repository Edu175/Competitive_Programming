#pragma once 

void findLocation(int n, int first, int location[], int stype[]);
