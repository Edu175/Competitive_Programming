#include <string>
#include <vector>

using namespace std;

int cadenas(int a) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
