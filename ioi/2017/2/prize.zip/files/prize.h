#include <vector>

int find_best(int n);
std::vector<int> ask(int i);
