#ifndef SKOLIB_H
#define SKOLIB_H

int daj_n();
int pytanie(int x, int y);
void odpowiedz(int xs, int ys);

#endif