#include <string>
#include <vector>

using namespace std;

long long superbicis(vector<long long> &x, vector<long long> &y, vector<int> &c) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
