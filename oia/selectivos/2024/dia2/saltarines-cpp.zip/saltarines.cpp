#include <string>
#include <vector>

using namespace std;

long long saltarines(int K, vector<int> &elegancias, vector<int> &ubicaciones) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
