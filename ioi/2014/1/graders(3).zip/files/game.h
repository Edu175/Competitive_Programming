#pragma once

void initialize(int n);
int hasEdge(int u, int v);

