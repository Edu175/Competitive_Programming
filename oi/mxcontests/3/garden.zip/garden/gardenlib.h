void answer(int x);
