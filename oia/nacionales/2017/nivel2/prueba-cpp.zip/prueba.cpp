#include <string>

using namespace std;

int  prueba( string palabra )
{
    // Aqui se debe completar con la solucion al problema
}
