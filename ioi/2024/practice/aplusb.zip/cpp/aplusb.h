int sum(int A, int B);
