#pragma once

#include <vector>

long long plan_roller_coaster(std::vector<int> s, std::vector<int> t);
