#include <string>
#include <vector>

using namespace std;

int cubrecadena(string &S, vector<string> &t) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
