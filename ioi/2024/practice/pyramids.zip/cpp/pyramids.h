#include <vector>

void init(std::vector<int> A, std::vector<int> B);
bool can_transform(int L, int R, int X, int Y);
