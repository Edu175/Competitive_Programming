#include "lane.h"

int solve(int c) {
  ask();
  clockwise();
  ask();
  flip();
  ask();
  return 2;
}
