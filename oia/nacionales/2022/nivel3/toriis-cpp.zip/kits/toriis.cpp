#include <string>
#include <vector>

using namespace std;

int toriis(int N, vector<int> &inicio, vector<int> &fin, vector<long long> &cantidad) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
