#include <string>
#include <vector>

using namespace std;

long long escribiendo(long long C, vector<long long> &numeros) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
