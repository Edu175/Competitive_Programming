#include "railroad_c.h"

long long plan_roller_coaster(int n, int *s, int *t) {
    return 0;
}
