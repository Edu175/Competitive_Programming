#include <string>
#include <vector>

using namespace std;

long long plantas(vector<int> &h) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
