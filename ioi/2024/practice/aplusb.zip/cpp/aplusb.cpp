#include "aplusb.h"

int sum(int A, int B) {
  return A + B - 1;
}
