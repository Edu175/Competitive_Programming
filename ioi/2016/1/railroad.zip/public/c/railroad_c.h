#pragma once

long long plan_roller_coaster(int n, int* s, int* t);
